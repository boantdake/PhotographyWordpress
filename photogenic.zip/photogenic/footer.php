				</div>
			</div>
  		</div>
	</div>
<footer>
	<p><?php bloginfo('name');?> &copy Dake Development</p>
</footer>
<?php wp_footer(); ?>
</body>

</html>