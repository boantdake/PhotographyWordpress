<?php
//theme support
require_once('widgets/class-wp-widget-categories.php');


function theme_setup(){
	//featured image support
	add_theme_support('post-thumbnails');

	set_post_thumbnail_size(900,600);

	//post format support
	add_theme_support('post-formats', array('gallery'));
}
//have to have this to get it going
add_action('after_setup_theme', 'theme_setup');

//widget locations
function init_widgets($id){
	register_sidebar(array(
		'name' => 'Sidebar',
		'id' => 'sidebar'

		));
}
add_action('widgets_init', 'init_widgets');

//register widgets
function custom_register_widgets(){
	register_widget('WP_Widget_Categories_Custom');
}
add_action('widgets_init', 'custom_register_widgets');